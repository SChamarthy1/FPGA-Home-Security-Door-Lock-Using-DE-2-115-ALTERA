# Pins for keypad_test.v   (Quartus: Tools > Tcl Scripts > Run)
set PROJECT_NAME "keypad_test"
package require ::quartus::project
if {[is_project_open]} { puts "Project already open." } else { project_open $PROJECT_NAME }

set_location_assignment PIN_Y2   -to clk
set_location_assignment PIN_Y23  -to reset      ;# SW17
set_location_assignment PIN_AB28 -to switch     ;# SW0

set_location_assignment PIN_AB22 -to Row[0]
set_location_assignment PIN_AC15 -to Row[1]
set_location_assignment PIN_AB21 -to Row[2]
set_location_assignment PIN_Y17  -to Row[3]
set_location_assignment PIN_AC21 -to Col[0]
set_location_assignment PIN_Y16  -to Col[1]
set_location_assignment PIN_AD21 -to Col[2]
set_location_assignment PIN_AE16 -to Col[3]

set_instance_assignment -name WEAK_PULL_UP_RESISTOR ON -to Row[0]
set_instance_assignment -name WEAK_PULL_UP_RESISTOR ON -to Row[1]
set_instance_assignment -name WEAK_PULL_UP_RESISTOR ON -to Row[2]
set_instance_assignment -name WEAK_PULL_UP_RESISTOR ON -to Row[3]

# LEDR[3:0] = rows_live
set_location_assignment PIN_G19 -to rows_live[0]
set_location_assignment PIN_F19 -to rows_live[1]
set_location_assignment PIN_E19 -to rows_live[2]
set_location_assignment PIN_F21 -to rows_live[3]
# LEDR[7:4] = last_key
set_location_assignment PIN_F18 -to last_key[0]
set_location_assignment PIN_E18 -to last_key[1]
set_location_assignment PIN_J19 -to last_key[2]
set_location_assignment PIN_H19 -to last_key[3]
# LEDG[7:0] = press_count
set_location_assignment PIN_E21 -to press_count[0]
set_location_assignment PIN_E22 -to press_count[1]
set_location_assignment PIN_E25 -to press_count[2]
set_location_assignment PIN_E24 -to press_count[3]
set_location_assignment PIN_H21 -to press_count[4]
set_location_assignment PIN_G20 -to press_count[5]
set_location_assignment PIN_G22 -to press_count[6]
set_location_assignment PIN_G21 -to press_count[7]

export_assignments
project_close
puts "Keypad test pins applied."
