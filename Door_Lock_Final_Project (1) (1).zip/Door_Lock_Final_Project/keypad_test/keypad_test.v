// ---------------------------------------------------------
// keypad_test.v   (5-minute keypad check, uses only LEDs)
// Use this BEFORE the lock project to see if your keypad and
// wires are fine.
//   LEDR[3:0] : show which keypad row is pressed right now
//   LEDR[7:4] : the last key found, in binary (2 = 0010, 6 = 0110, C = 1100)
//   LEDG[7:0] : how many keys were accepted (binary counter)
// Press ONE key ONE time -> LEDG must go up by exactly 1.
// SW17 up = set the counter back to 0.   SW0 must be up.
// ---------------------------------------------------------
module keypad_test (
    input        clk,
    input        reset,        // SW17, up = counter back to 0
    input        switch,       // SW0, up = keypad on
    input  [3:0] Row,
    output [3:0] Col,
    output [3:0] rows_live,    // LEDR[3:0]
    output [3:0] last_key,     // LEDR[7:4]
    output reg [7:0] press_count   // LEDG[7:0]
);

    wire [3:0] key_code;
    wire       key_valid;

    keypad_decoder u_decoder (
        .clk       (clk),
        .pb        (1'b1),
        .switch    (switch),
        .Row       (Row),
        .Col       (Col),
        .DecodeOut (key_code),
        .key_valid (key_valid)
    );

    assign rows_live = ~Row;       // light on = that row is low (pressed)
    assign last_key  = key_code;

    always @(posedge clk or posedge reset) begin
        if (reset)          press_count <= 8'd0;
        else if (key_valid) press_count <= press_count + 8'd1;
    end

endmodule
