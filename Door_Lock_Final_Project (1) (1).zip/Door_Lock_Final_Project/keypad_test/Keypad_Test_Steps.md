# Keypad Check — 5 minutes

Do this first. It tells you if the keypad and the wires are good, without the lock.

1. New Quartus project named `keypad_test`, device EP4CE115F29C7, top module `keypad_test`.
   Add two files: `keypad_test.v` and `keypad_decoder.v`.
2. Tools > Tcl Scripts > run `keypad_test_pins.tcl`. Compile. Program the board.
3. SW0 up, SW17 down. All green LEDs are off (count = 0).
4. Press key `2` once, count to one second, let go.
   - Green LED 0 lights = 1 key counted. Good.
   - Red LEDs 7..4 show `0010`. Good (2 in binary).
5. Press `6`: green count goes to 2, red 7..4 show `0110`. Press `C`: count 3, red shows `1100`.
6. Do this for all 16 keys. Write down any key that gives the wrong red pattern.

Binary of each key (red LEDs 7..4 as 3-2-1-0):
1=0001 2=0010 3=0011 4=0100 5=0101 6=0110 7=0111 8=1000 9=1001 0=0000 A=1010 B=1011 C=1100 D=1101 *=1110 #=1111

What it means:
| You see | Problem is |
|---|---|
| One press = count +1, key patterns right | Keypad and wires are good. The lock project will work. |
| One press = count +2 or more | Wires or keypad. Check step 7 of the guide (shorter wires, firm connection). |
| Count goes up with nobody pressing | A row wire is loose or floating. Re-seat the 4 row wires. Check the pull-up pins were set. |
| A key gives a wrong pattern | Two wires are swapped or in the wrong hole. |
| Nothing happens | SW0 down, wires off, or pins not set. |
